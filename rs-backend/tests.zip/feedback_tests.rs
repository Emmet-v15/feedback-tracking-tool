use axum::{body::{Body, to_bytes}, http::{Request, StatusCode}};
use tower::ServiceExt;
use serde_json::Value;
use sqlx::PgPool;
use rs_backend::routes::{feedback, feedback_label};

#[sqlx::test(migrations = "./migrations")]
async fn test_get_feedback(pool: PgPool) {
    // Register a test user and fetch the actual user ID
    sqlx::query!("INSERT INTO users (username, password_hash, email, role) VALUES ($1, $2, $3, $4)",
        "testuser", "$argon2id$v=19$m=4096,t=3,p=1$someSalt$someHash", "test@example.com", "student")
        .execute(&pool)
        .await
        .unwrap();
    let user = sqlx::query!("SELECT id FROM users WHERE username = $1", "testuser")
        .fetch_one(&pool)
        .await
        .unwrap();
    let claims = rs_backend::models::user::Claims {
        sub: user.id,
        exp: (chrono::Utc::now() + chrono::Duration::hours(1)).timestamp() as usize,
        username: "testuser".to_string(),
        role: "student".to_string(),
    };
    let jwt_secret = std::env::var("JWT_SECRET").unwrap_or_else(|_| "testsecret".to_string());
    let token = jsonwebtoken::encode(
        &jsonwebtoken::Header::default(),
        &claims,
        &jsonwebtoken::EncodingKey::from_secret(jwt_secret.as_bytes()),
    ).unwrap();

    // Insert a project for the feedback to reference
    let project = sqlx::query!("INSERT INTO projects (name, description, owner_id) VALUES ($1, $2, $3) RETURNING id",
        "Test Project", "desc", user.id)
        .fetch_one(&pool)
        .await
        .unwrap();
    // Insert a feedback for the user and project
    sqlx::query!("INSERT INTO feedback (title, description, status, priority, creator_id, project_id) VALUES ($1, $2, $3, $4, $5, $6)",
        "Test Feedback", "desc", "open", "low", user.id, project.id)
        .execute(&pool)
        .await
        .unwrap();

    let app = feedback::routes().with_state(pool.clone());
    let res = app
        .oneshot(Request::builder().uri("/").header("Authorization", format!("Bearer {}", token)).body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
}

#[sqlx::test(migrations = "./migrations")]
async fn test_get_feedback_by_id(pool: PgPool) {
    let app = axum::Router::new()
        .route("/{project_id}/feedback/{feedback_id}", axum::routing::get(feedback::get_feedback_by_id))
        .with_state(pool.clone());
    let res = app
        .oneshot(Request::builder().uri("/1/feedback/1").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let v: Option<Value> = serde_json::from_slice(&body).unwrap();
    assert!(v.is_none());
}

#[sqlx::test(migrations = "./migrations")]
async fn test_get_feedback_labels(pool: PgPool) {
    let app = feedback_label::routes().with_state(pool.clone());
    let res = app
        .oneshot(Request::builder().uri("/1").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let v: Vec<Value> = serde_json::from_slice(&body).unwrap();
    assert!(v.is_empty());
}
