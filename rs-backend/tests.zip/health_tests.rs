use axum::{body::{Body, to_bytes}, http::{Request, StatusCode}};
use tower::ServiceExt; // Import ServiceExt to use `oneshot`
use rs_backend::routes::health;

#[tokio::test]
async fn test_health_endpoint() {
    let app = health::routes();
    let req = Request::builder()
        .uri("/health")
        .body(Body::empty())
        .unwrap();
    let res = app.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let v: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(v["message"], "API is healthy");
}
