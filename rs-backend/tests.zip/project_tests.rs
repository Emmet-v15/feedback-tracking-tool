use axum::{body::{Body, to_bytes}, http::{Request, StatusCode}};
use tower::ServiceExt;
use serde_json::Value;
use sqlx::PgPool;
use rs_backend::routes::{project, label};

#[sqlx::test(migrations = "./migrations")]
async fn test_get_projects(pool: PgPool) {
    let app = project::routes().with_state(pool.clone());
    let res = app
        .oneshot(Request::builder().uri("/").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let v: Vec<Value> = serde_json::from_slice(&body).unwrap();
    assert!(v.is_empty());
}

#[sqlx::test(migrations = "./migrations")]
async fn test_get_project_by_id(pool: PgPool) {
    let app = project::routes().with_state(pool.clone());
    let res = app
        .oneshot(Request::builder().uri("/1").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let v: Option<Value> = serde_json::from_slice(&body).unwrap();
    assert!(v.is_none());
}

#[sqlx::test(migrations = "./migrations")]
async fn test_get_labels(pool: PgPool) {
    let app = label::routes().with_state(pool.clone());
    let res = app
        .oneshot(Request::builder().uri("/label").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let v: Vec<Value> = serde_json::from_slice(&body).unwrap();
    assert!(v.is_empty());
}

#[sqlx::test(migrations = "./migrations")]
async fn test_get_label_by_id(pool: PgPool) {
    let app = label::routes().with_state(pool.clone());
    let res = app
        .oneshot(Request::builder().uri("/label/1").body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let v: Option<Value> = serde_json::from_slice(&body).unwrap();
    assert!(v.is_none());
}

#[sqlx::test(migrations = "./migrations")]
async fn test_create_and_delete_label(pool: PgPool) {
    use serde_json::json;

    // Create a user first
    let user_payload = serde_json::json!({
        "username": "testuser_label",
        "password": "testpass123",
        "email": "testuser_label@example.com",
        "role": "admin"
    });
    let app_auth = rs_backend::routes::auth::routes().with_state(pool.clone());
    let req = Request::builder()
        .method("POST")
        .uri("/register")
        .header("content-type", "application/json")
        .body(Body::from(user_payload.to_string()))
        .unwrap();
    let res = app_auth.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::CREATED);
    // Login to get JWT
    let login_payload = serde_json::json!({
        "username": "testuser_label",
        "password": "testpass123"
    });
    let req = Request::builder()
        .method("POST")
        .uri("/login")
        .header("content-type", "application/json")
        .body(Body::from(login_payload.to_string()))
        .unwrap();
    let res = app_auth.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let token: String = serde_json::from_slice(&body).unwrap();
    // Fetch user to get id
    let app_user = rs_backend::routes::user::routes().with_state(pool.clone());
    let res = app_user.clone().oneshot(
        Request::builder().uri("/user").header("Authorization", format!("Bearer {}", token)).body(Body::empty()).unwrap()
    ).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let users: Vec<Value> = serde_json::from_slice(&body).unwrap();
    let created_user = users.iter().find(|u| u["username"] == "testuser_label").expect("User not found");
    let user_id = created_user["id"].as_i64().unwrap();

    // Create a project first
    let project_payload = serde_json::json!({
        "name": "Test Project",
        "description": "A test project.",
        "ownerId": user_id
    });
    let app_project = project::routes().with_state(pool.clone());
    let req = Request::builder()
        .method("POST")
        .uri("/")
        .header("content-type", "application/json")
        .header("Authorization", format!("Bearer {}", token))
        .body(Body::from(project_payload.to_string()))
        .unwrap();
    let res = app_project.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::CREATED);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let created_project: Value = serde_json::from_slice(&body).unwrap();
    let project_id = created_project["id"].as_i64().unwrap();

    // Ensure project creation is committed before creating label
    pool.acquire().await.unwrap();

    let app = label::routes().with_state(pool.clone());

    // Create a label for the created project (no auth required)
    let payload = json!({
        "name": "Bug",
        "color": "#ff0000",
        "project_id": project_id
    });
    let req = Request::builder()
        .method("POST")
        .uri("/label")
        .header("content-type", "application/json")
        .body(Body::from(payload.to_string()))
        .unwrap();
    let res = app.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::CREATED);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let created: Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(created["name"], "Bug");
    let label_id = created["id"].as_i64().unwrap();

    // Delete the label (no auth required)
    let req = Request::builder()
        .method("DELETE")
        .uri(&format!("/label/{}", label_id))
        .body(Body::empty())
        .unwrap();
    let res = app.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let deleted: Option<Value> = serde_json::from_slice(&body).unwrap();
    assert!(deleted.is_some());
}