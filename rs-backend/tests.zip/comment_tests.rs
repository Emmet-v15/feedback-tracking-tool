use axum::{body::Body, http::{Request, StatusCode}};
use tower::ServiceExt;
use sqlx::PgPool;
use rs_backend::routes::feedback_comment;

#[sqlx::test(migrations = "./migrations")]
async fn test_get_comments(pool: PgPool) {
    // Register a test user and fetch the actual user ID
    sqlx::query!("INSERT INTO users (username, password_hash, email, role) VALUES ($1, $2, $3, $4)",
        "testuser", "$argon2id$v=19$m=4096,t=3,p=1$someSalt$someHash", "test@example.com", "student")
        .execute(&pool)
        .await
        .unwrap();
    let user = sqlx::query!("SELECT id FROM users WHERE username = $1", "testuser")
        .fetch_one(&pool)
        .await
        .unwrap();

    // Insert a project and feedback for the comment to reference
    let project = sqlx::query!("INSERT INTO projects (name, description, owner_id) VALUES ($1, $2, $3) RETURNING id",
        "Test Project", "desc", user.id)
        .fetch_one(&pool)
        .await
        .unwrap();
    let feedback = sqlx::query!("INSERT INTO feedback (title, description, status, priority, creator_id, project_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id",
        "Test Feedback", "desc", "open", "low", user.id, project.id)
        .fetch_one(&pool)
        .await
        .unwrap();
    // Insert a comment for the feedback
    sqlx::query!("INSERT INTO comments (content, user_id, feedback_id) VALUES ($1, $2, $3)",
        "Test Comment", user.id, feedback.id)
        .execute(&pool)
        .await
        .unwrap();

    // Manually create a valid JWT for the test user
    let claims = rs_backend::models::user::Claims {
        sub: user.id,
        exp: (chrono::Utc::now() + chrono::Duration::hours(1)).timestamp() as usize,
        username: "testuser".to_string(),
        role: "student".to_string(),
    };
    let jwt_secret = std::env::var("JWT_SECRET").unwrap_or_else(|_| "testsecret".to_string());
    let token = jsonwebtoken::encode(
        &jsonwebtoken::Header::default(),
        &claims,
        &jsonwebtoken::EncodingKey::from_secret(jwt_secret.as_bytes()),
    ).unwrap();

    let app = feedback_comment::routes().with_state(pool.clone());
    let res = app
        .oneshot(Request::builder()
            .uri("/")
            .header("Authorization", format!("Bearer {}", token))
            .body(Body::empty()).unwrap())
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
}
