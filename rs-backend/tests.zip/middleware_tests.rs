use axum::{Router, routing::get, body::{Body, to_bytes}, http::{Request, StatusCode, header::HeaderValue}};
use axum::http::header::AUTHORIZATION;
use axum::extract::ConnectInfo;
use tower::ServiceExt;
use std::net::{IpAddr, Ipv4Addr, SocketAddr};

use rs_backend::middleware::real_ip::get_ip_from_headers;
use rs_backend::middleware::auth::{auth_middleware, AuthContext};

// Unit tests for real_ip header parsing
#[test]
fn test_get_ip_from_x_real_ip() {
    let mut headers = axum::http::HeaderMap::new();
    headers.insert("X-Real-IP", HeaderValue::from_static("192.168.0.1"));
    assert_eq!(get_ip_from_headers(&headers), Some("192.168.0.1".parse().unwrap()));
}

#[test]
fn test_get_ip_from_x_forwarded_for() {
    let mut headers = axum::http::HeaderMap::new();
    headers.insert("X-Forwarded-For", HeaderValue::from_static("10.0.0.1, 10.0.0.2"));
    assert_eq!(get_ip_from_headers(&headers), Some("10.0.0.1".parse().unwrap()));
}

#[test]
fn test_get_ip_from_headers_none() {
    let headers = axum::http::HeaderMap::new();
    assert_eq!(get_ip_from_headers(&headers), None);
}

// Integration tests for RealIp extractor
#[tokio::test]
async fn test_real_ip_extractor_header() {
    let app = Router::new().route("/", get(|rs_backend::middleware::real_ip::RealIp(ip): rs_backend::middleware::real_ip::RealIp| async move { ip.to_string() }));
    let req = Request::builder()
        .uri("/")
        .header("X-Real-IP", "8.8.8.8")
        .body(Body::empty())
        .unwrap();
    let res = app.oneshot(req).await.unwrap();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    assert_eq!(body, "8.8.8.8");
}

#[tokio::test]
async fn test_real_ip_extractor_connect_info() {
    let app = Router::new().route("/", get(|rs_backend::middleware::real_ip::RealIp(ip): rs_backend::middleware::real_ip::RealIp| async move { ip.to_string() }));
    let socket = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(1,2,3,4)), 0);
    let req = Request::builder().uri("/").body(Body::empty()).unwrap();
    // attach ConnectInfo extension
    let mut req = req;
    req.extensions_mut().insert(ConnectInfo(socket));
    let res = app.oneshot(req).await.unwrap();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    assert_eq!(body, "1.2.3.4");
}

// Integration tests for auth_middleware
#[tokio::test]
async fn test_auth_missing_header() {
    let app = Router::new().route("/", get(|| async { "ok" })).layer(axum::middleware::from_fn(auth_middleware));
    let req = Request::builder().uri("/").body(Body::empty()).unwrap();
    let res = app.oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_auth_invalid_token() {
    unsafe { std::env::set_var("JWT_SECRET", "test_secret"); }
    let app = Router::new().route("/", get(|| async { "ok" })).layer(axum::middleware::from_fn(auth_middleware));
    let req = Request::builder()
        .uri("/")
        .header(AUTHORIZATION, "Bearer invalid.token")
        .body(Body::empty())
        .unwrap();
    let res = app.oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_auth_valid_token_allows_access() {
    unsafe { std::env::set_var("JWT_SECRET", "test_secret"); }
    use jsonwebtoken::{encode, Header, EncodingKey};
    let claims = rs_backend::models::user::Claims { sub: 42, exp: 9999999999, username: "user".into(), role: "admin".into() };
    let token = encode(&Header::default(), &claims, &EncodingKey::from_secret(b"test_secret")).unwrap();

    let app = Router::new().route("/", get(|| async { "ok" })).layer(axum::middleware::from_fn(auth_middleware));
    let req = Request::builder()
        .uri("/")
        .header(AUTHORIZATION, format!("Bearer {}", token))
        .body(Body::empty())
        .unwrap();
    let res = app.oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
}

#[tokio::test]
async fn test_auth_context_extractor_in_handler() {
    unsafe { std::env::set_var("JWT_SECRET", "test_secret"); }
    use jsonwebtoken::{encode, Header, EncodingKey};
    let claims = rs_backend::models::user::Claims { sub: 7, exp: 9999999999, username: "alice".into(), role: "admin".into() };
    let token = encode(&Header::default(), &claims, &EncodingKey::from_secret(b"test_secret")).unwrap();

    let app = Router::new()
        .route("/", get(|auth_ctx: AuthContext| async move { format!("{}:{}", auth_ctx.user_id, auth_ctx.username) }))
        .layer(axum::middleware::from_fn(auth_middleware));

    let req = Request::builder()
        .uri("/")
        .header(AUTHORIZATION, format!("Bearer {}", token))
        .body(Body::empty())
        .unwrap();
    let res = app.oneshot(req).await.unwrap();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    assert_eq!(body, "7:alice");
}