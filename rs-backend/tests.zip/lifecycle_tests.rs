use axum::{body::{Body, to_bytes}, http::{Request, StatusCode}};
use tower::ServiceExt;
use serde_json::{Value, json};
use sqlx::PgPool;
use rs_backend::routes::{project, feedback_comment, user};

#[sqlx::test(migrations = "./migrations")]
async fn test_full_project_feedback_comment_lifecycle(pool: PgPool) {
    // register user via /register
    let app_auth = rs_backend::routes::auth::routes().with_state(pool.clone());
    let register_payload = json!({
        "username": "testuser",
        "password": "yay123",
        "email": "test@example.com",
        "role": "admin"
    });
    let req = Request::builder()
        .method("POST")
        .uri("/register")
        .header("content-type", "application/json")
        .body(Body::from(register_payload.to_string()))
        .unwrap();
    let res = app_auth.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::CREATED);

    // login to get JWT
    let login_payload = json!({
        "username": "testuser",
        "password": "yay123"
    });
    let req = Request::builder()
        .method("POST")
        .uri("/login")
        .header("content-type", "application/json")
        .body(Body::from(login_payload.to_string()))
        .unwrap();
    let res = app_auth.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let token: String = serde_json::from_slice(&body).unwrap();

    // fetch user by username to get user_id
    let app_user = user::routes().with_state(pool.clone());
    let res = app_user.clone().oneshot(
        Request::builder()
            .uri("/user")
            .header("Authorization", format!("Bearer {}", token))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let users: Vec<Value> = serde_json::from_slice(&body).unwrap();
    let created_user = users.iter().find(|u| u["username"] == "testuser").expect("User not found");
    let user_id = created_user["id"].as_i64().unwrap() as i32;

    // create project
    let app_proj = project::routes().with_state(pool.clone());
    let project_payload = json!({
        "name": "Test Project",
        "description": "A test project.",
        "ownerId": user_id
    });
    let req = Request::builder()
        .method("POST")
        .uri("/")
        .header("content-type", "application/json")
        .header("Authorization", format!("Bearer {}", token))
        .body(Body::from(project_payload.to_string()))
        .unwrap();
    let res = app_proj.clone().oneshot(req).await.unwrap();
    let status = res.status();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    eprintln!("Project creation status: {}", status);
    eprintln!("Project creation body: {}", String::from_utf8_lossy(&body));
    assert_eq!(status, StatusCode::CREATED);
    let created_project: Value = serde_json::from_slice(&body).unwrap();
    let project_id = created_project["id"].as_i64().unwrap() as i32;

    // get project by id
    let res = app_proj.oneshot(
        Request::builder()
            .uri(&format!("/{}", project_id))
            .header("Authorization", format!("Bearer {}", token))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    let status = res.status();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    eprintln!("Get project by id status: {}", status);
    eprintln!("Get project by id body: {}", String::from_utf8_lossy(&body));
    assert_eq!(status, StatusCode::OK);
    let fetched_project: Option<Value> = serde_json::from_slice(&body).unwrap();
    let fetched_project = fetched_project.unwrap();
    assert_eq!(fetched_project["name"], "Test Project");

    // create feedback
    let app_proj_with_feedback = project::routes().with_state(pool.clone());
    let feedback_payload = json!({
        "title": "Test Feedback",
        "description": "Feedback description",
        "status": "open",
        "priority": "low",
        "creatorId": user_id,
        "projectId": project_id
    });
    let req = Request::builder()
        .method("POST")
        .uri(&format!("/{}/feedback/", project_id))
        .header("content-type", "application/json")
        .header("Authorization", format!("Bearer {}", token))
        .body(Body::from(feedback_payload.to_string()))
        .unwrap();
    let res = app_proj_with_feedback.clone().oneshot(req).await.unwrap();
    let status = res.status();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    eprintln!("Feedback creation status: {}", status);
    eprintln!("Feedback creation body: {}", String::from_utf8_lossy(&body));
    if status != StatusCode::CREATED {
        panic!("Feedback creation failed: status = {}, body = {}", status, String::from_utf8_lossy(&body));
    }
    assert_eq!(status, StatusCode::CREATED);
    let created_feedback: Value = serde_json::from_slice(&body).unwrap();
    let feedback_id = created_feedback["id"].as_i64().unwrap() as i32;

    // get feedback by id
    let res = app_proj_with_feedback.oneshot(
        Request::builder()
            .uri(&format!("/{}/feedback/{}", project_id, feedback_id))
            .header("Authorization", format!("Bearer {}", token))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    let status = res.status();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    eprintln!("Get feedback by id status: {}", status);
    eprintln!("Get feedback by id body: {}", String::from_utf8_lossy(&body));
    assert_eq!(status, StatusCode::OK);
    let fetched_feedback: Option<Value> = serde_json::from_slice(&body).unwrap();
    let fetched_feedback = fetched_feedback.unwrap();
    assert_eq!(fetched_feedback["title"], "Test Feedback");

    // create comment
    let app_cmt = feedback_comment::routes().with_state(pool.clone());
    let comment_payload = json!({
        "content": "Test Comment",
        "user_id": user_id,
        "feedback_id": feedback_id
    });
    let req = Request::builder()
        .method("POST")
        .uri("/")
        .header("content-type", "application/json")
        .header("Authorization", format!("Bearer {}", token))
        .body(Body::from(comment_payload.to_string()))
        .unwrap();
    let res = app_cmt.clone().oneshot(req).await.unwrap();
    let status = res.status();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    eprintln!("Comment creation status: {}", status);
    eprintln!("Comment creation body: {}", String::from_utf8_lossy(&body));
    assert_eq!(status, StatusCode::CREATED);
    let created_comment: Value = serde_json::from_slice(&body).unwrap();
    let comment_id = created_comment["id"].as_i64().unwrap() as i32;

    // get comments and verify presence
    let res = app_cmt.clone().oneshot(
        Request::builder()
            .uri("/")
            .header("Authorization", format!("Bearer {}", token))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let comments: Vec<Value> = serde_json::from_slice(&body).unwrap();
    assert!(comments.iter().any(|c| c["id"] == json!(comment_id)));

    // delete comment
    let res = app_cmt.clone().oneshot(
        Request::builder()
            .method("DELETE")
            .uri(&format!("/{}", comment_id))
            .header("Authorization", format!("Bearer {}", token))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);

    // ensure comments list is empty
    let res = app_cmt.clone().oneshot(
        Request::builder()
            .uri("/")
            .header("Authorization", format!("Bearer {}", token))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let comments: Vec<Value> = serde_json::from_slice(&body).unwrap();
    assert!(comments.is_empty());

    // create label (no auth required)
    let app_label = rs_backend::routes::label::routes().with_state(pool.clone());
    let label_payload = json!({
        "name": "Urgent",
        "color": "#ff0000",
        "project_id": project_id
    });
    let req = Request::builder()
        .method("POST")
        .uri("/label")
        .header("content-type", "application/json")
        .body(Body::from(label_payload.to_string()))
        .unwrap();
    let res = app_label.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::CREATED);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let created_label: Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(created_label["name"], "Urgent");
    let label_id = created_label["id"].as_i64().unwrap();

    // get label by id (no auth required)
    let res = app_label.clone().oneshot(
        Request::builder()
            .uri(&format!("/label/{}", label_id))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let fetched_label: Option<Value> = serde_json::from_slice(&body).unwrap();
    assert_eq!(fetched_label.as_ref().unwrap()["name"], "Urgent");

    // delete label (no auth required)
    let res = app_label.clone().oneshot(
        Request::builder()
            .method("DELETE")
            .uri(&format!("/label/{}", label_id))
            .body(Body::empty())
            .unwrap()
    ).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = to_bytes(res.into_body(), usize::MAX).await.unwrap();
    let deleted_label: Option<Value> = serde_json::from_slice(&body).unwrap();
    assert!(deleted_label.is_some());
}
